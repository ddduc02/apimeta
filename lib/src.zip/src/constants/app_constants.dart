const List<String> countriesAvailable = ['VN', 'BE', 'AU' ];
